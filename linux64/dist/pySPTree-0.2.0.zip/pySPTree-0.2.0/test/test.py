import pyio_034 as io
from pprint import pprint

ret = io.ShortestPathSolver('sample.dmx',2)
pprint(ret)
